import streamlit as st
import pickle
import numpy as np

# ---------------------------------------------------------
# Page Configuration
# ---------------------------------------------------------
st.set_page_config(
    page_title="Churn Risk Intelligence Hub",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------------------------------------------------------
# Load Assets
# ---------------------------------------------------------
@st.cache_resource
def load_assets():
    model = pickle.load(open("random_forest_churn_model.pkl", "rb"))
    scaler = pickle.load(open("scaler.pkl", "rb"))
    return model, scaler

try:
    model, scaler = load_assets()
except FileNotFoundError:
    st.error("⚠️ Model files (`random_forest_churn_model.pkl` or `scaler.pkl`) missing. Please verify asset paths.")
    st.stop()

# ---------------------------------------------------------
# Custom Styling (Glassmorphism & Vibrant UI)
# ---------------------------------------------------------
st.markdown("""
    <style>
    /* Global Reset & Base Theme Adjustments */
    .stApp {
        background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%);
        color: #f8fafc;
    }
    
    /* Card Container */
    .glass-card {
        background: rgba(255, 255, 255, 0.05);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 16px;
        padding: 24px;
        margin-bottom: 20px;
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
    }

    /* Vibrant Buttons */
    .stButton > button {
        width: 100%;
        background: linear-gradient(90deg, #6366f1 0%, #8b5cf6 100%);
        color: #ffffff;
        font-weight: 700;
        font-size: 1.1rem;
        border: none;
        border-radius: 12px;
        padding: 0.75rem 1.5rem;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(99, 102, 241, 0.4);
    }
    .stButton > button:hover {
        background: linear-gradient(90deg, #4f46e5 0%, #7c3aed 100%);
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(99, 102, 241, 0.6);
    }

    /* Section Subheaders */
    .section-title {
        font-size: 1.25rem;
        font-weight: 600;
        color: #818cf8;
        margin-bottom: 1rem;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    /* Custom Risk Badges */
    .risk-badge-low {
        background-color: rgba(34, 197, 94, 0.15);
        color: #4ade80;
        border: 1px solid rgba(34, 197, 94, 0.3);
        padding: 6px 14px;
        border-radius: 20px;
        font-weight: 600;
    }
    .risk-badge-high {
        background-color: rgba(239, 68, 68, 0.15);
        color: #f87171;
        border: 1px solid rgba(239, 68, 68, 0.3);
        padding: 6px 14px;
        border-radius: 20px;
        font-weight: 600;
    }
    </style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------
# Sidebar - Global Quick Filters & Presets
# ---------------------------------------------------------
with st.sidebar:
    st.image("https://img.icons8.com/isometric-radar/100/analytics.png", width=70)
    st.title("Control Panel")
    st.caption("Manage environment defaults & presets")
    
    preset = st.selectbox("Load Test Profile", ["Custom Input", "High Risk Profile (Germany)", "Low Risk Profile (France)"])
    
    st.markdown("---")
    st.info("💡 **Model Confidence:** Trained on Random Forest Architecture with Standard Scaling.")

# Dynamic Defaults based on Presets
if preset == "High Risk Profile (Germany)":
    d_gender, d_country, d_age, d_salary = "Female", "Germany", 52, 125000.0
    d_credit, d_balance, d_tenure, d_products, d_card, d_active = 580, 110000.0, 2, 1, "No", "No"
elif preset == "Low Risk Profile (France)":
    d_gender, d_country, d_age, d_salary = "Male", "France", 28, 65000.0
    d_credit, d_balance, d_tenure, d_products, d_card, d_active = 740, 45000.0, 7, 2, "Yes", "Yes"
else:
    d_gender, d_country, d_age, d_salary = "Male", "France", 35, 50000.0
    d_credit, d_balance, d_tenure, d_products, d_card, d_active = 650, 50000.0, 5, 2, "Yes", "Yes"

# ---------------------------------------------------------
# Dashboard Header
# ---------------------------------------------------------
st.markdown("""
    <div style='text-align: left; padding-bottom: 20px;'>
        <h1 style='font-size: 2.5rem; font-weight: 800; background: linear-gradient(90deg, #818cf8, #c084fc); -webkit-background-clip: text; -webkit-text-fill-color: transparent;'>
            ⚡ Customer Churn Intelligence Dashboard
        </h1>
        <p style='color: #94a3b8; font-size: 1.05rem;'>
            Real-time customer risk analysis, predictive modeling, and strategic retention recommendations.
        </p>
    </div>
""", unsafe_allow_html=True)

# ---------------------------------------------------------
# Input Matrix Layout
# ---------------------------------------------------------
st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
col1, col2 = st.columns(2, gap="large")

with col1:
    st.markdown("<div class='section-title'>👤 Demographic Profile</div>", unsafe_allow_html=True)
    
    sub1, sub2 = st.columns(2)
    with sub1:
        gender = st.selectbox("Gender", ["Male", "Female"], index=["Male", "Female"].index(d_gender))
    with sub2:
        country = st.selectbox("Country Location", ["France", "Germany", "Spain"], index=["France", "Germany", "Spain"].index(d_country))
        
    age = st.slider("Customer Age (Years)", min_value=18, max_value=90, value=d_age)
    salary = st.number_input("Estimated Annual Salary ($)", min_value=0.0, max_value=250000.0, value=d_salary, step=5000.0)

with col2:
    st.markdown("<div class='section-title'>🏦 Account & Financial Health</div>", unsafe_allow_html=True)
    
    credit_score = st.slider("Credit Score Indicator", min_value=300, max_value=850, value=d_credit)
    balance = st.number_input("Current Account Balance ($)", min_value=0.0, max_value=300000.0, value=d_balance, step=5000.0)
    
    sub3, sub4 = st.columns(2)
    with sub3:
        tenure = st.number_input("Tenure (Years)", min_value=0, max_value=10, value=d_tenure)
        num_products = st.number_input("Active Products Held", min_value=1, max_value=4, value=d_products)
    with sub4:
        has_card = st.selectbox("Credit Card Holder", ["Yes", "No"], index=["Yes", "No"].index(d_card))
        active_member = st.selectbox("Active Engagement", ["Yes", "No"], index=["Yes", "No"].index(d_active))

st.markdown("</div>", unsafe_allow_html=True)

# Feature Encoding Transformation
germany = 1 if country == "Germany" else 0
spain = 1 if country == "Spain" else 0
male = 1 if gender == "Male" else 0
has_card_val = 1 if has_card == "Yes" else 0
active_member_val = 1 if active_member == "Yes" else 0

# ---------------------------------------------------------
# Model Execution & Predictive Output
# ---------------------------------------------------------
if st.button("🚀 Evaluate Churn Risk Score"):
    
    # Feature array ordering matching standard trained baseline
    data = np.array([[
        credit_score,
        age,
        tenure,
        balance,
        num_products,
        has_card_val,
        active_member_val,
        salary,
        germany,
        spain,
        male
    ]])

    scaled_data = scaler.transform(data)
    prediction = model.predict(scaled_data)[0]
    prediction_proba = model.predict_proba(scaled_data)[0][1] * 100

    st.markdown("### 📊 Assessment Summary")
    
    res_col1, res_col2 = st.columns([1, 1], gap="medium")

    with res_col1:
        st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
        st.subheader("Predictive Risk Gauge")
        
        # Display Probability Metric
        st.metric(
            label="Exit Risk Probability", 
            value=f"{prediction_proba:.1f}%", 
            delta=f"{'High' if prediction_proba >= 50 else 'Low'} Probability Tier",
            delta_color="inverse" if prediction_proba >= 50 else "normal"
        )
        
        # Streamlit Progress Indicator bar
        st.progress(int(prediction_proba))
        
        if prediction == 1:
            st.markdown("<span class='risk-badge-high'>CRITICAL CHURN RISK DETECTED</span>", unsafe_allow_html=True)
        else:
            st.markdown("<span class='risk-badge-low'>STABLE - RETENTION LIKELY</span>", unsafe_allow_html=True)
            
        st.markdown("</div>", unsafe_allow_html=True)

    with res_col2:
        st.markdown("<div class='glass-card'>", unsafe_allow_html=True)
        st.subheader("💡 Strategic Action Plan")
        
        if prediction == 1:
            st.error("Primary Drivers Identified: Age threshold / Product concentration / Engagement drops.")
            st.markdown("""
                * **Immediate Step:** Trigger high-touch outreach program via personal relationship manager.
                * **Incentive:** Offer premium rate adjustments on zero-balance fees or reward upgrades.
                * **Engagement:** Schedule a product feedback review to resolve usage friction.
            """)
        else:
            st.success("Customer profile exhibits strong loyalty markers.")
            st.markdown("""
                * **Cross-sell Opportunity:** Eligible for investment portfolio or secondary loan product tiers.
                * **Retention:** Enroll in automatic multi-product fee waivers to maintain loyalty.
                * **Monitoring:** Maintain regular quarterly communication touchpoints.
            """)
            
        st.markdown("</div>", unsafe_allow_html=True)

    # Key Contributing Metrics Row
    st.markdown("#### Key Factor Snapshots")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Customer Segment", f"{country}")
    m2.metric("Engagement State", "Active" if active_member_val else "Inactive")
    m3.metric("Product Diversity", f"{num_products} Held")
    m4.metric("Relationship Age", f"{tenure} Yrs")